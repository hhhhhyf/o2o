package com.cjlu.o2o.dao;

import com.cjlu.o2o.entity.Area;

import java.util.List;

public interface AreaDao {

    List<Area> queryArea();
}
