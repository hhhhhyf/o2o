package com.cjlu.o2o.service.impl;

import com.cjlu.o2o.entity.Area;

import java.util.List;

public interface AreaService {
    List<Area> getAreaList();
}
